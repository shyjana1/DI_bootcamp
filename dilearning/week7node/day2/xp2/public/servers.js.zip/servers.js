

const exp = require('express');

const app = exp();

app.route('/')
    .get((req,res)=>{
        console.log(req.query);
            res.send({message: 'OK'})
    })
    app.use('/',exp.static(__dirname+'/index.html'));
app.listen(3000);

