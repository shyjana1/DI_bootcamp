export const changePropOne = (value) => {
  return {
    type: 'PROP_ONE',
    payload: value
  }
}

export const changePropTwo = () => {
  return {
    type: 'PROP_TWO',
  }
}
