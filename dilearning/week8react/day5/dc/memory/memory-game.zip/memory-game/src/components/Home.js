import React from 'react'

const Home = (props) => {
  return (
    <>
    <h1>Home</h1>
    {props.say}
    </>
  )
}
export default Home
