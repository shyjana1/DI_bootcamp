import React from 'react'

const Contact = (props) => {
  return (
    <>
    <h1>Contact</h1>
    {props.artem}
    </>
  )
}
export default Contact
